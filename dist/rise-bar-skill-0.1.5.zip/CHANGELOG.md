# Changelog

## 0.1.5 — 2026-11-16

- Recorded the approved Elsewhen header: active bar font, native typography and close control, with a 12px title-to-separator gap.
- Added scope-freeze, connected panel surface and active-variant action-style guidance without redesigning approved city/globe content.
- Added Wayland capture/backend diagnosis, current-image comparison, settled IPC and cached-component replacement gates.
- Documented real-pointer fixture versus live-input limits and short scratch-path recovery for IPC socket failures.
- Updated validation scope, the versioned archive and checksums. No new cross-agent or marketplace acceptance is claimed.

## 0.1.4 — 2026-11-13

- Documented effective locale-derived hour controls, explicit preference preservation and native motion semantics.
- Added theme-check deadline diagnosis and slow-remote/pinned-apply regression guidance.
- Recorded final checkout validation, repeated native display checks and installed World Clock rendering without claiming exact original parity or warning-free lint.
- Rebuilt and verified the versioned archive and checksums. Historical agent/platform evaluation limits remain unchanged.

## 0.1.3 — 2026-11-12

- Added World Clock/Elsewhen shared ownership, native-original comparison, interaction, IPC and translation/notification validation guidance.
- Added staged rollback/takeover, actual-file comparisons, reviewed deployment and preserved-preference gates.
- Replaced stale slot-count assumptions with current-schema discovery and tray-aware migration guidance.
- Added scratch-path/Unix-socket diagnostics and installed-tree/ShellCheck verification boundaries.
- Recorded the tested Rise candidate and live installation evidence without claiming warning-free lint or universal agent acceptance.
- Rebuilt the versioned distribution and checksums.

## 0.1.2 — 2026-11-04

- Updated OneDrive guidance for the OneDrive title, native UiText rendering, the V1 pill adapter and themed preferences.
- Recorded content-height expansion, hidden scrollbar and manual scrolling without auto-scroll on opening preferences.
- Added current V1/V2 slot capacities, saved-layout preservation and scaled empty-slot drag validation.
- Documented consistent 90-second query limits and evidence-based timeout diagnosis.
- Documented the benign first-party `omarchy.bar` IPC collision and added live checkout/installation validation evidence.
- Updated the validation report, distribution archive and SHA-256 checksums; new skill behavior has not been independently retested across agents.

## 0.1.1 — 2026-11-04

- Added a widget-integration reference for shared ownership, append-only slot migration, popup routing and external plugin adaptation.
- Documented the local OneDrive integration, active-theme styling, name-only header, separator and bar icon sizing.
- Recorded focused mocked tests, real import-graph compilation and account-side-effect boundaries.
- Rebuilt the distribution archive and checksums; agent behavior for the new reference has not been retested.

## 0.1.0 — 2026-11-04

- Documented agent installation paths and successful Copilot CLI 1.0.105 discovery, activation, and reference-reading checks.
- Separated basic bar installation from optional AI collectors, CAVA, and recovery hook.
- Recorded source baseline `02c54552208f8ee099cc60d0a35d65adc8f4be8e`, collector data access, persistence, removal, and partial-failure recovery.
- Added task-specific requirements, explicit validation limits, MCP text-delivery guidance, and log-redaction instructions.
- Added the MIT License for the skill package.
- Validated the skill and revised Copilot behavior; passed isolated collector-installation and lifecycle/recovery/uninstall regression suites.
- Packaged the distribution ZIP with MIT license, version, validation report and SHA-256 checksum.
- Platform delivery, additional agent behavior and live desktop validation remain pending; see VALIDATION.md.
